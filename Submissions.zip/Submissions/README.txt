The files for the regression problem is located in the Regression folder. 
I have used iPython Notebook for this problem.
I have included the codes in an .ipynb file as well as a PDF which includes both the codes and the Markdown explanations 
for each step.
I have also included the codes in an executable .py file.
The final predicted values on the test set is included in the predicted_target_test.txt file.

The files for the baby_names problem is located in the Baby_Names folder. 
I have used iPython Notebook for this problem.
I have included the codes in an .ipynb file as well as a PDF which includes both the codes and the Markdown explanations 
for each step.
I have also included the codes in an executable .py file.

In order to be able to fit all the Notebook into a PDF file I had to write each line of codes in multiples lines which may not look neat! Have already reported this “bug” to Jupyter!
